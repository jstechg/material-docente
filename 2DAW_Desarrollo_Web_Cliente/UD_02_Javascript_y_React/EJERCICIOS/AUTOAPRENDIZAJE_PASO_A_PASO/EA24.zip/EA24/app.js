"use strict";

const entrada = [
  [1, 0, 0],
  [0, 0, 1],
  [0, 0, 0],
];

function contarVecinos(matriz, fila, columna) {
  let total = 0;

  for (let df = -1; df <= 1; df++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (df === 0 && dc === 0) continue;

      const f = fila + df;
      const c = columna + dc;
      const dentro = f >= 0 && f < matriz.length && c >= 0 && c < matriz[0].length;
      if (dentro && matriz[f][c] === 1) total++;
    }
  }
  return total;
}

function generarMapa(matriz) {
  return matriz.map((fila, i) =>
    fila.map((valor, j) => (valor === 1 ? -1 : contarVecinos(matriz, i, j))),
  );
}

console.log(entrada);
console.log(generarMapa(entrada));