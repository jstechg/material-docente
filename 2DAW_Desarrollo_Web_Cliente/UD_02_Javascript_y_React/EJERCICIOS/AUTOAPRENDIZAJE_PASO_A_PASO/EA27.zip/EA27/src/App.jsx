import Panel from "./components/Panel.jsx";

function App() {
  return (
    <main>
      <Panel titulo="Recordatorio">
        <p>Usa nombres lowerCamelCase en JavaScript.</p>
      </Panel>

      <Panel titulo="Objetivo">
        <p>Separar la interfaz en piezas reutilizables.</p>
        <strong>Este contenido llega mediante children.</strong>
      </Panel>
    </main>
  );
}

export default App;