"use strict";

console.log(`Antes de asignar total: ${total}`); // undefined por hoisting
var total = 12;

if (true) {
  var visibleEnFuncion = "var sale del bloque";
  let soloEnBloque = "let se queda en el bloque";
  const LIMITE = 5;

  console.log(visibleEnFuncion);
  console.log(soloEnBloque);
  console.log(LIMITE);
}

console.log(visibleEnFuncion);
// console.log(soloEnBloque); // Descomentar para observar el error.
// console.log(LIMITE);       // Descomentar para observar el error.

const configuracion = { modo: "aula" };
configuracion.modo = "práctica"; // Se modifica el contenido del objeto.
console.log(configuracion);