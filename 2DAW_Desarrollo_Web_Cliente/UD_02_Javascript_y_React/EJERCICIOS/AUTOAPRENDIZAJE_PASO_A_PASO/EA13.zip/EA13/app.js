"use strict";

const dispositivo = {
  nombre: "Sensor A1",
  activo: true,
  ubicacion: {
    aula: "A-12",
    planta: 1,
  },
  etiquetas: ["iot", "temperatura"],
  descripcion: function () {
    return `${this.nombre} en ${this.ubicacion.aula}`;
  },
};

console.log(dispositivo.nombre);
console.log(dispositivo["activo"]);
console.log(dispositivo.ubicacion.planta);

dispositivo.fabricante = "Laboratorio DWEC";
console.log(dispositivo.descripcion());
console.log(dispositivo.red?.ip); // undefined sin lanzar excepción
console.log(dispositivo);