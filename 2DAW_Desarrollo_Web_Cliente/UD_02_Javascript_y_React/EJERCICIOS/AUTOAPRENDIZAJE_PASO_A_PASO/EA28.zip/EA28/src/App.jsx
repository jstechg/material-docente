import EstadoEntrega from "./components/EstadoEntrega.jsx";

function App() {
  return (
    <main>
      <EstadoEntrega completada={false} porcentaje={40} />
      <hr />
      <EstadoEntrega completada={true} porcentaje={100} />
    </main>
  );
}

export default App;