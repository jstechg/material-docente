function EstadoEntrega({ completada, porcentaje }) {
  const texto = completada ? "Entrega completada" : "Entrega pendiente";

  return (
    <>
      <h2 className="estado-titulo">{texto}</h2>
      <p>Progreso: {porcentaje}%</p>
      <p>{porcentaje >= 50 ? "Buen avance" : "Conviene continuar"}</p>
    </>
  );
}

export default EstadoEntrega;