import "./ListaRecursos.css";

function ListaRecursos({ recursos }) {
  return (
    <section className="recursos">
      <h2>Recursos de estudio</h2>
      <ul>
        {recursos.map((recurso) => (
          <li key={recurso.id}>
            <strong>{recurso.codigo}</strong>: {recurso.nombre}
          </li>
        ))}
      </ul>
    </section>
  );
}

export default ListaRecursos;