import ListaRecursos from "./components/ListaRecursos.jsx";

function App() {
  const recursos = [
    { id: 1, codigo: "JS", nombre: "Sintaxis" },
    { id: 2, codigo: "OBJ", nombre: "Objetos" },
    { id: 3, codigo: "REACT", nombre: "Componentes" },
  ];

  return (
    <main>
      <ListaRecursos recursos={recursos} />
    </main>
  );
}

export default App;