"use strict";

/** Calcula el importe de una reserva. */
function calcularReserva(precioDia, dias, descuento = 0) {
  if (isNaN(precioDia) || isNaN(dias) || isNaN(descuento)) {
    return null;
  }

  const subtotal = precioDia * dias;
  return subtotal - (subtotal * descuento) / 100;
}

function mostrarReserva(nombre, precioDia, dias, descuento = 0) {
  const total = calcularReserva(precioDia, dias, descuento);

  if (total === null) {
    console.error("Datos numéricos no válidos");
    return;
  }

  console.log(`${nombre}: ${dias} días -> ${total.toFixed(2)} €`);
}

mostrarReserva("Aula móvil", 25, 3);
mostrarReserva("Laboratorio", 40, 2, 10);
mostrarReserva("Dato erróneo", "x", 2, 5);