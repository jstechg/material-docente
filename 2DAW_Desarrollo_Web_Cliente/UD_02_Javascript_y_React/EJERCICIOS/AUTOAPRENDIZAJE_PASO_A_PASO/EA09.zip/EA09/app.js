"use strict";

function mediaFlexible() {
  if (arguments.length < 2) {
    console.error("Se necesitan al menos dos valores");
    return null;
  }

  let suma = 0;
  for (let i = 0; i < arguments.length; i++) {
    if (typeof arguments[i] !== "number" || isNaN(arguments[i])) {
      console.error(`El argumento ${i + 1} no es numérico`);
      return null;
    }
    suma += arguments[i];
  }

  return suma / arguments.length;
}

console.log(mediaFlexible(6, 8, 7));
console.log(mediaFlexible(9));
console.log(mediaFlexible(5, "7", 8));