"use strict";

function enteroAleatorio(minimo, maximo) {
  return Math.floor(Math.random() * (maximo - minimo + 1)) + minimo;
}

function generarMuestra(cantidad, minimo, maximo) {
  const valores = [];

  while (valores.length < cantidad) {
    const candidato = enteroAleatorio(minimo, maximo);
    if (valores.indexOf(candidato) === -1) {
      valores.push(candidato);
    }
  }

  return valores;
}

const muestra = generarMuestra(5, 10, 20);
console.log(muestra);
console.log(`Mínimo: ${Math.min(...muestra)}`);
console.log(`Máximo: ${Math.max(...muestra)}`);
console.log(`Raíz del máximo: ${Math.sqrt(Math.max(...muestra)).toFixed(2)}`);