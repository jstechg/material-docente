"use strict";

const temperaturas = [19, 21, 20, 23];
console.log(`Inicial: ${temperaturas.join(" - ")}`);

temperaturas.push(25);
console.log(`Después de push: ${temperaturas.join(" - ")}`);

const eliminado = temperaturas.pop();
console.log(`Se retiró: ${eliminado}`);

let suma = 0;
for (let i = 0; i < temperaturas.length; i++) {
  suma += temperaturas[i];
}
const media = suma / temperaturas.length;

console.log(`Media: ${media.toFixed(2)}`);
console.log(`Dos valores centrales: ${temperaturas.slice(1, 3).join(", ")}`);
console.log(`Primera temperatura > 20: ${temperaturas.find((t) => t > 20)}`);