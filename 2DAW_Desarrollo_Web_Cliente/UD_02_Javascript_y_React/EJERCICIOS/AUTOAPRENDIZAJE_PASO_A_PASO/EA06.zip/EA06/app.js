"use strict";

console.log("Pares del 2 al 10");
for (let numero = 2; numero <= 10; numero += 2) {
  console.log(numero);
}

let suma = 0;
let siguiente = 1;
while (suma < 15) {
  suma += siguiente;
  siguiente++;
}
console.log(`La suma alcanzó ${suma}`);

let intento = 0;
do {
  intento++;
  console.log(`Intento ${intento}`);
} while (intento < 2);

console.log("Saltamos 3 y paramos al llegar a 7");
for (let i = 1; i <= 10; i++) {
  if (i === 3) continue;
  if (i === 7) break;
  console.log(i);
}