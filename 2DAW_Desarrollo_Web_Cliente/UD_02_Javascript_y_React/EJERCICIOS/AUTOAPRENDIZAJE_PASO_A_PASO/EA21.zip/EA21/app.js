"use strict";

const matriz = [
  [2, 4, 1, 3],
  [5, 0, 2, 1],
  [3, 3, 4, 2],
];

for (let fila = 0; fila < matriz.length; fila++) {
  let sumaFila = 0;
  let textoFila = "";

  for (let columna = 0; columna < matriz[fila].length; columna++) {
    const valor = matriz[fila][columna];
    sumaFila += valor;
    textoFila += `${valor} `;
  }

  console.log(`Fila ${fila}: ${textoFila} | suma=${sumaFila}`);
}