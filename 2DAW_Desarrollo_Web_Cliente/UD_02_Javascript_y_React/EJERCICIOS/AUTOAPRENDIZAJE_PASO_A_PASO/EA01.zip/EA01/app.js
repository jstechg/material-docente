"use strict";

const modulo = "Desarrollo Web en Entorno Cliente";
let unidad = 2;
const horasSemanales = 3;
let entornoPreparado = true;

console.log(`Módulo: ${modulo}`);
console.log(`Unidad: ${unidad}`);
console.log(`Horas semanales: ${horasSemanales}`);
console.log(`Entorno preparado: ${entornoPreparado}`);

unidad = 3;
console.log(`Después del cambio, unidad vale: ${unidad}`);