import FichaCurso from "./components/FichaCurso.jsx";

function App() {
  const participantes = [
    { id: 1, nombre: "Alicia", rol: "desarrollo", presentacion: "Trabaja con JavaScript." },
    { id: 2, nombre: "Bruno", rol: "diseño", presentacion: "Cuida la presentación visual." },
  ];

  return (
    <FichaCurso
      titulo="Taller de interfaces"
      coordinador="Equipo DWEC"
      participantes={participantes}
    >
      <p>Ejemplo de composición de componentes, props, children y listas.</p>
    </FichaCurso>
  );
}

export default App;