function Persona({ nombre, rol, children }) {
  return (
    <article className="persona">
      <h3>{nombre}</h3>
      <p>Rol: {rol}</p>
      <div>{children}</div>
    </article>
  );
}

export default Persona;