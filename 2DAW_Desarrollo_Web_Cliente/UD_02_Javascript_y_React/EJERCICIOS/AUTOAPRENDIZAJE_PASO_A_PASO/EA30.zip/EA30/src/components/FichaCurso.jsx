import Persona from "./Persona.jsx";
import "./FichaCurso.css";

function FichaCurso({ titulo, coordinador, participantes, children }) {
  return (
    <section className="ficha-curso">
      <h1>{titulo}</h1>
      <p>Coordinación: {coordinador}</p>
      <div className="descripcion">{children}</div>

      <h2>Participantes</h2>
      {participantes.length === 0 ? (
        <p>No hay participantes.</p>
      ) : (
        participantes.map((persona) => (
          <Persona key={persona.id} nombre={persona.nombre} rol={persona.rol}>
            <p>{persona.presentacion}</p>
          </Persona>
        ))
      )}
    </section>
  );
}

export default FichaCurso;