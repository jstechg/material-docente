"use strict";

const referencia = "dwec:ut02:js-17";
const partes = referencia.split(":");

const modulo = partes[0].toUpperCase();
const unidad = partes[1].toUpperCase();
const codigo = partes[2].replace("js", "javascript");

console.log(`Longitud: ${referencia.length}`);
console.log(`Módulo: ${modulo}`);
console.log(`Unidad: ${unidad}`);
console.log(`Código: ${codigo}`);
console.log(`Primer carácter: ${referencia.charAt(0)}`);
console.log(`Posición de ut02: ${referencia.indexOf("ut02")}`);
console.log(`Prefijo: ${referencia.substring(0, 4)}`);
console.log(`Original intacta: ${referencia}`);