"use strict";

const precioTexto = "18.75";
const unidadesTexto = "4";

const precio = Number(precioTexto);
const unidades = parseInt(unidadesTexto, 10);
const total = precio * unidades;

console.log(`Tipos originales: ${typeof precioTexto}, ${typeof unidadesTexto}`);
console.log(`Tipos convertidos: ${typeof precio}, ${typeof unidades}`);
console.log(`Total: ${total.toFixed(2)} €`);

console.log(5 == "5");   // true: hay coerción
console.log(5 === "5");  // false: comparación estricta

const entradaIncorrecta = "dieciocho";
console.log(`¿No es número? ${isNaN(Number(entradaIncorrecta))}`);
console.log(String(2026));
console.log(parseFloat("3.50"));