"use strict";

function hayDuplicados(valores) {
  for (let i = 0; i < valores.length; i++) {
    for (let j = i + 1; j < valores.length; j++) {
      if (valores[i] === valores[j]) {
        return true;
      }
    }
  }
  return false;
}

console.log(hayDuplicados([4, 7, 2, 9, 5]));
console.log(hayDuplicados([4, 7, 2, 7, 5]));