"use strict";

function procesarValores(valores, operacion) {
  const resultado = [];
  for (let i = 0; i < valores.length; i++) {
    resultado.push(operacion(valores[i]));
  }
  return resultado;
}

function aplicarRecargo(valor) {
  return valor * 1.1;
}

const pasarAMilimetros = (centimetros) => centimetros * 10;

const precios = [10, 20, 35];
const longitudes = [2, 4.5, 8];

console.log(procesarValores(precios, aplicarRecargo));
console.log(procesarValores(longitudes, pasarAMilimetros));