"use strict";

console.log(declarada(4));
function declarada(valor) {
  return valor * 2;
}

const expresion = function (valor) {
  return valor + 3;
};

const flecha = (valor) => valor ** 2;

console.log(expresion(4));
console.log(flecha(4));

(function () {
  console.log("IIFE: se ejecuta una sola vez al definirse");
})();

const mensajeExterior = "visible por scope chain";
function exterior() {
  const mensajeIntermedio = "también visible";
  function interior() {
    console.log(mensajeExterior);
    console.log(mensajeIntermedio);
  }
  interior();
}
exterior();