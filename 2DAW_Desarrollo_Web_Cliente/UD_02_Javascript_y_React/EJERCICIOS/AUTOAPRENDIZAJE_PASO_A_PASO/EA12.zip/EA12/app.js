"use strict";

const consumos = [120, 95, 180, 60, 140];

consumos.forEach((valor, indice) => {
  console.log(`Lectura ${indice}: ${valor} W`);
});

const enKilovatios = consumos.map((valor) => valor / 1000);
const altos = consumos.filter((valor) => valor >= 130);
const todosPositivos = consumos.every((valor) => valor > 0);
const existeBajo = consumos.some((valor) => valor < 80);
const total = consumos.reduce((acumulador, valor) => acumulador + valor, 0);

console.log(enKilovatios);
console.log(altos);
console.log(todosPositivos);
console.log(existeBajo);
console.log(`Total: ${total} W`);