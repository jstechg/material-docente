"use strict";

function metrosACentimetros(metros) {
  return metros * 100;
}

function centimetrosAMetros(centimetros) {
  return centimetros / 100;
}

export { metrosACentimetros, centimetrosAMetros };