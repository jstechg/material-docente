"use strict";

import {
  metrosACentimetros,
  centimetrosAMetros as aMetros,
} from "./utilidades/longitudes.js";

console.log(metrosACentimetros(2.5));
console.log(aMetros(350));