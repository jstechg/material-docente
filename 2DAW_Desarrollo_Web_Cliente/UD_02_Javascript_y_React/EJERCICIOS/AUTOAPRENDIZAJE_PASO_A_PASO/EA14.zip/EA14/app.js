"use strict";

function crearTaller(nombre, aula, anio, herramientas) {
  return {
    nombre,
    aula,
    anio,
    herramientas,
    resumen: function () {
      return `${this.nombre} (${this.anio}) - ${this.aula}`;
    },
  };
}

function mostrarPropiedades(objeto) {
  for (const propiedad in objeto) {
    if (typeof objeto[propiedad] !== "function") {
      console.log(`${propiedad}: ${objeto[propiedad]}`);
    }
  }
}

const taller = crearTaller("Montaje web", "B-04", 2026, ["VS Code", "Chrome"]);
console.log(taller.resumen());
mostrarPropiedades(taller);