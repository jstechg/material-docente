"use strict";

const ahora = new Date();
const entrega = new Date(2026, 9, 20, 12, 0, 0); // octubre = 9
const mismaEntrega = new Date(2026, 9, 20, 12, 0, 0);

console.log(`Año: ${entrega.getFullYear()}`);
console.log(`Mes (0-11): ${entrega.getMonth()}`);
console.log(`Día: ${entrega.getDate()}`);

const diaSiguiente = new Date(entrega.getTime());
diaSiguiente.setDate(diaSiguiente.getDate() + 1);
console.log(diaSiguiente);

console.log(`¿Ahora es anterior a la entrega? ${ahora < entrega}`);
console.log(`¿Mismo instante? ${entrega.getTime() === mismaEntrega.getTime()}`);