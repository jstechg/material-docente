"use strict";

const evento = {
  titulo: "Taller de JavaScript",
  aula: "A-03",
  participantes: ["Leo", "Marta"],
};

const texto = JSON.stringify(evento);
console.log(texto);

const reconstruido = JSON.parse(texto);
console.log(reconstruido);

const actualizado = {
  ...evento,
  participantes: [...evento.participantes, "Nora"],
};

const { titulo, aula, participantes } = actualizado;
console.log(`${titulo} - ${aula}`);
console.log(participantes);
console.log(evento.participantes); // el original no cambia

try {
  JSON.parse("{json incorrecto}");
} catch (error) {
  console.warn("Se ha detectado un texto JSON no válido");
}