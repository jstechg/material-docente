"use strict";

function hayDuplicados(valores) {
  return valores.some((valor, indice) => valores.indexOf(valor) !== indice);
}

function filasValidas(matriz) {
  return matriz.every((fila) => !hayDuplicados(fila));
}

function columnasValidas(matriz) {
  for (let columna = 0; columna < matriz[0].length; columna++) {
    const valoresColumna = [];
    for (let fila = 0; fila < matriz.length; fila++) {
      valoresColumna.push(matriz[fila][columna]);
    }
    if (hayDuplicados(valoresColumna)) return false;
  }
  return true;
}

const cuadrícula = [
  [1, 2, 3, 4],
  [2, 3, 4, 1],
  [3, 4, 1, 2],
  [4, 1, 2, 3],
];

console.log(`Filas válidas: ${filasValidas(cuadrícula)}`);
console.log(`Columnas válidas: ${columnasValidas(cuadrícula)}`);