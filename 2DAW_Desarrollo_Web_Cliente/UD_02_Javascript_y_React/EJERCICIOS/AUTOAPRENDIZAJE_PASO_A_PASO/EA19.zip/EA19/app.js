"use strict";

const alias = prompt("Introduce un alias:", "alumno");
const comenzar = confirm(`¿Iniciar la prueba para ${alias ?? "sin alias"}?`);

if (comenzar) {
  let contador = 0;

  const idIntervalo = setInterval(() => {
    contador++;
    console.log(`Pulso ${contador}`);

    if (contador === 5) {
      clearInterval(idIntervalo);
      console.log("Intervalo detenido");
    }
  }, 1000);

  setTimeout(() => {
    console.log("Mensaje programado: revisión final");
  }, 7000);
} else {
  console.log("Prueba cancelada por el usuario");
}