function App() {
  return (
    <main>
      <h1>DWEC - UT02</h1>
      <p>Primer componente funcional.</p>
      <p>El JSX se devuelve desde return.</p>
    </main>
  );
}

export default App;