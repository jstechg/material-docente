"use strict";

const edad = 20;
const nombre = "Lucía";
const activo = true;
let datoSinValor;
const seleccion = null;
const ficha = { grupo: "2DAW" };

console.log(typeof edad);
console.log(typeof nombre);
console.log(typeof activo);
console.log(typeof datoSinValor);
console.log(typeof seleccion); // peculiaridad histórica: "object"
console.log(seleccion === null);
console.log(typeof ficha);
console.log(typeof function ejemplo() {});

function cambiarNumero(numero) {
  numero = 99;
}

function cambiarFicha(objeto) {
  objeto.grupo = "2DAW-S";
}

let puntos = 10;
cambiarNumero(puntos);
cambiarFicha(ficha);

console.log(`puntos sigue valiendo ${puntos}`);
console.log(`ficha.grupo ahora vale ${ficha.grupo}`);