import TarjetaModulo from "./components/TarjetaModulo.jsx";

function App() {
  return (
    <main>
      <h1>Módulos</h1>
      <TarjetaModulo nombre="DWEC" curso="2.º DAW" horas={3} />
      <TarjetaModulo nombre="Sistemas Informáticos" curso="1.º DAW" horas={5} />
    </main>
  );
}

export default App;