function TarjetaModulo({ nombre, curso, horas }) {
  return (
    <article>
      <h2>{nombre}</h2>
      <p>Curso: {curso}</p>
      <p>Horas semanales: {horas}</p>
    </article>
  );
}

export default TarjetaModulo;