"use strict";

const importe = 82;
const esSocio = true;
let aliasCliente;
let descuento = 0;
let categoria;

if (importe >= 100) {
  descuento = 15;
  categoria = "pedido grande";
} else if (importe >= 50) {
  descuento = esSocio ? 10 : 5;
  categoria = "pedido medio";
} else {
  categoria = "pedido pequeño";
}

const importeFinal = importe - (importe * descuento) / 100;
const nombreVisible = aliasCliente ?? "Cliente sin alias";

console.log(`${nombreVisible}: ${categoria}`);
console.log(`Descuento: ${descuento}%`);
console.log(`Total: ${importeFinal.toFixed(2)} €`);
console.log(`¿Descuento aplicado? ${descuento > 0 && importe > 0}`);