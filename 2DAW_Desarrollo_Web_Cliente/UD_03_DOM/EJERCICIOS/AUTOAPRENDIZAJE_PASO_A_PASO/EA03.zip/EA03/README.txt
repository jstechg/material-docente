EA03 - Selectores DOM: id, clase y selectores CSS

Abrir estos ficheros dentro de ~/DWEC/UT03/EA03 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
