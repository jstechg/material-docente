"use strict";

const titulo = document.getElementById("titulo");
const primerAviso = document.querySelector(".aviso");
const avisos = document.querySelectorAll("p.aviso");

console.log(titulo.textContent);
console.log(primerAviso.textContent);
console.log("Número de avisos:", avisos.length);
avisos.forEach((aviso) => console.log("-", aviso.textContent));
