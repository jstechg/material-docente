EA04 - Colecciones vivas y estáticas

Abrir estos ficheros dentro de ~/DWEC/UT03/EA04 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
