"use strict";

const vivas = document.getElementsByClassName("tarjeta");
const instantanea = document.querySelectorAll(".tarjeta");
console.log("Antes:", vivas.length, instantanea.length);

const nueva = document.createElement("p");
nueva.className = "tarjeta";
nueva.textContent = "Tres";
document.querySelector("#panel").append(nueva);

console.log("Después:", vivas.length, instantanea.length);
