"use strict";

const pendientes = document.querySelector("#pendientes");
const resueltas = document.querySelector("#resueltas");

document.querySelector("#panel").addEventListener("click", (evento) => {
  const boton = evento.target.closest("button[data-accion]");
  if (!boton) return;
  const tarjeta = boton.closest(".incidencia");
  if (boton.dataset.accion === "borrar") { tarjeta.remove(); return; }
  const estaResuelta = tarjeta.classList.toggle("resuelta");
  (estaResuelta ? resueltas : pendientes).append(tarjeta);
  boton.textContent = estaResuelta ? "Reabrir" : "Resolver";
});
