EA19 - Mover elementos entre listas y delegar acciones

Abrir estos ficheros dentro de ~/DWEC/UT03/EA19 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
