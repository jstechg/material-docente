EA09 - Cambiar apariencia con classList

Abrir estos ficheros dentro de ~/DWEC/UT03/EA09 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
