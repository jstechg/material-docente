"use strict";

const aviso = document.querySelector("#aviso");
document.querySelector("#cambiar").addEventListener("click", () => {
  aviso.classList.toggle("prioritario");
  console.log("Prioritario:", aviso.classList.contains("prioritario"));
});
