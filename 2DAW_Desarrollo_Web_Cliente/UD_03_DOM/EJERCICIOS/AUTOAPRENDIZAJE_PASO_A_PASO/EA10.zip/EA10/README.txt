EA10 - textContent frente a innerHTML

Abrir estos ficheros dentro de ~/DWEC/UT03/EA10 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
