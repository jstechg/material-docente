"use strict";

const mensaje = "<strong>Revisión completada</strong>";
document.querySelector("#texto").textContent = mensaje;
document.querySelector("#html").innerHTML = mensaje;
