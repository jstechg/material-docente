EA08 - Atributos, propiedades y dataset

Abrir estos ficheros dentro de ~/DWEC/UT03/EA08 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
