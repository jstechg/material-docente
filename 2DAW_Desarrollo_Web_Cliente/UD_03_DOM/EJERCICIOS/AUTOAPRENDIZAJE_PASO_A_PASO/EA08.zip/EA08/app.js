"use strict";

const recurso = document.querySelector("#recurso");
recurso.href = "https://developer.mozilla.org/es/docs/Web/API/Document";
recurso.setAttribute("target", "_blank");
recurso.dataset.nivel = "intermedio";

document.querySelector("#estado").textContent =
  `Nivel: ${recurso.dataset.nivel} · destino: ${recurso.href}`;
