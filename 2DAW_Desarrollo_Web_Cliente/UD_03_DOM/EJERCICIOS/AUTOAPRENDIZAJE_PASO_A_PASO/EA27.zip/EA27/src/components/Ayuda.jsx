import { useRef } from "react";
import "./Ayuda.css";
function Ayuda() {
  const panelRef = useRef(null);
  const alternar = () => panelRef.current?.classList.toggle("visible");
  return <section><button onClick={alternar}>Mostrar / ocultar ayuda</button><div ref={panelRef} className="ayuda">Recuerda inspeccionar el DOM.</div></section>;
}
export default Ayuda;
