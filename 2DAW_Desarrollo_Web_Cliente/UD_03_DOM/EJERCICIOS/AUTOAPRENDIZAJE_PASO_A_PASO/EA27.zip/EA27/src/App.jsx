import Ayuda from "./components/Ayuda.jsx";
function App() { return <main><h1>Ayuda contextual</h1><Ayuda /></main>; }
export default App;
