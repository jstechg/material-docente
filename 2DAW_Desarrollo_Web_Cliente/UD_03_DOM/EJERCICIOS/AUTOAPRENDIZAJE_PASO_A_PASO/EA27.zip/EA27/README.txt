EA27 - useRef y clases CSS: mostrar y ocultar un panel

Crear primero un proyecto Vite React según el documento EA27.docx. Copiar estos ficheros dentro de src.
