EA01 - window, document y location: reconocer el entorno del navegador

Abrir estos ficheros dentro de ~/DWEC/UT03/EA01 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
