"use strict";

console.log("Título:", document.title);
console.log("URL:", location.href);
console.log("Ruta:", location.pathname);
console.log("Idioma:", navigator.language);
console.log("Ancho de ventana:", window.innerWidth);
