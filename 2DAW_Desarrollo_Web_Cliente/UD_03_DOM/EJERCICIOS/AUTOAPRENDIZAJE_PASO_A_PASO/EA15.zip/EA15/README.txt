EA15 - Tabla dinámica y marcado por condición

Abrir estos ficheros dentro de ~/DWEC/UT03/EA15 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
