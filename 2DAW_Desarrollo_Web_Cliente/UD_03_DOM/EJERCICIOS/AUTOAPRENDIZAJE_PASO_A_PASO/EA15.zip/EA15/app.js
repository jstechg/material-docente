"use strict";

const tabla = document.createElement("table");
let valor = 1;
for (let fila = 0; fila < 5; fila++) {
  const tr = document.createElement("tr");
  for (let columna = 0; columna < 5; columna++) {
    const td = document.createElement("td");
    td.textContent = valor++;
    tr.append(td);
  }
  tabla.append(tr);
}
document.querySelector("#contenedor").append(tabla);

const celdas = () => document.querySelectorAll("td");
document.querySelector("#marcar").addEventListener("click", () => {
  celdas().forEach((td) => td.classList.toggle("destacado", Number(td.textContent) % 4 === 0));
});
document.querySelector("#limpiar").addEventListener("click", () => {
  celdas().forEach((td) => td.classList.remove("destacado"));
});
