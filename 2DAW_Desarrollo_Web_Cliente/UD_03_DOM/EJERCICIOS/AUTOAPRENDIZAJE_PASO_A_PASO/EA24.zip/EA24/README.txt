EA24 - Catálogo React completo: JSON, componentes, props y children

Crear primero un proyecto Vite React según el documento EA24.docx. Copiar estos ficheros dentro de src.
