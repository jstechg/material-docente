function Sesion({ nombre }) { return <li>{nombre}</li>; }
export default Sesion;
