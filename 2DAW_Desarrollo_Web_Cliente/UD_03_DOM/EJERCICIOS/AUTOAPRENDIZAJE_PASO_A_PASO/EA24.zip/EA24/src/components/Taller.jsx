import Sesion from "./Sesion.jsx";
import "./Taller.css";
function Taller({ titulo, sesiones, children }) {
  return <article className="taller"><h2>{titulo}</h2><p>{children}</p><ul>{sesiones.map((s) => <Sesion key={s.id} nombre={s.nombre} />)}</ul></article>;
}
export default Taller;
