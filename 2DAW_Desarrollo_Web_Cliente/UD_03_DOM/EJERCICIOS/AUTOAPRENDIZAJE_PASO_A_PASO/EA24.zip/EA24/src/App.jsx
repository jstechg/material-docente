import datos from "./datos/talleres.json";
import Taller from "./components/Taller.jsx";
function App() {
  return <main><h1>Talleres</h1>{datos.talleres.map((t) => <Taller key={t.id} titulo={t.titulo} sesiones={t.sesiones}>{t.resumen}</Taller>)}</main>;
}
export default App;
