EA05 - Recorrer el DOM sólo por elementos

Abrir estos ficheros dentro de ~/DWEC/UT03/EA05 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
