"use strict";

const lista = document.querySelector("#puestos");
for (const hijo of lista.children) {
  console.log(hijo.textContent);
}

const actual = document.querySelector("#actual");
console.log("Anterior:", actual.previousElementSibling.textContent);
console.log("Siguiente:", actual.nextElementSibling.textContent);
