EA06 - Inspector de contenidos: contar, localizar y resumir elementos

Abrir estos ficheros dentro de ~/DWEC/UT03/EA06 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
