"use strict";

const parrafos = document.querySelectorAll("p");
const enlaces = document.querySelectorAll("a");
const resumen = document.querySelector("#resumen");

const datos = [
  `Párrafos: ${parrafos.length}`,
  `Segundo párrafo: ${parrafos[1].textContent}`,
  `Enlaces: ${enlaces.length}`,
  `Primer enlace: ${enlaces[0].href}`,
  `Último enlace: ${enlaces[enlaces.length - 1].href}`
];

const lista = document.createElement("ul");
datos.forEach((dato) => {
  const item = document.createElement("li");
  item.textContent = dato;
  lista.append(item);
});
resumen.append(lista);
