EA16 - Ocultar y restaurar tarjetas mediante clases

Abrir estos ficheros dentro de ~/DWEC/UT03/EA16 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
