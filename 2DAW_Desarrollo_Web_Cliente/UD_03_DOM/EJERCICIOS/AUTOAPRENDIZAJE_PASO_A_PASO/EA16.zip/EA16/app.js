"use strict";

const tarjetas = document.querySelectorAll(".tarjeta");
const fondos = ["fondo1", "fondo2", "fondo3"];

tarjetas.forEach((tarjeta) => {
  tarjeta.addEventListener("click", () => tarjeta.classList.add("oculta"));
  tarjeta.addEventListener("mouseout", () => {
    fondos.forEach((fondo) => tarjeta.classList.remove(fondo));
    const indice = Math.floor(Math.random() * fondos.length);
    tarjeta.classList.add(fondos[indice]);
  });
});

document.querySelector("#restaurar").addEventListener("click", () => {
  tarjetas.forEach((tarjeta) => {
    tarjeta.className = "tarjeta";
  });
});
