EA12 - Insertar antes y después de un elemento

Abrir estos ficheros dentro de ~/DWEC/UT03/EA12 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
