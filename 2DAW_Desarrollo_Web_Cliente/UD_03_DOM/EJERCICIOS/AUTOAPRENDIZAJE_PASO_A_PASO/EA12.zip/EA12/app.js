"use strict";

const codigo = document.querySelector("#codigo");
const analizar = document.createElement("li");
analizar.textContent = "Analizar";
const probar = document.createElement("li");
probar.textContent = "Probar";

codigo.before(analizar);
codigo.after(probar);
