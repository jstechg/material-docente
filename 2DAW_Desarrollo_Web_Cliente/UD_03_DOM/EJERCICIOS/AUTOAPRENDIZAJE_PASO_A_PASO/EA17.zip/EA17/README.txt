EA17 - Recorrido recursivo de nodos de texto

Abrir estos ficheros dentro de ~/DWEC/UT03/EA17 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
