"use strict";

function revisar(nodo) {
  for (const hijo of [...nodo.childNodes]) {
    if (hijo.nodeType === Node.TEXT_NODE && /spoiler/i.test(hijo.nodeValue)) {
      const span = document.createElement("span");
      span.className = "ocultado";
      span.textContent = hijo.nodeValue.replace(/spoiler/gi, "[contenido oculto]");
      hijo.replaceWith(span);
    } else if (hijo.nodeType === Node.ELEMENT_NODE) {
      revisar(hijo);
    }
  }
}

revisar(document.querySelector("#articulo"));
