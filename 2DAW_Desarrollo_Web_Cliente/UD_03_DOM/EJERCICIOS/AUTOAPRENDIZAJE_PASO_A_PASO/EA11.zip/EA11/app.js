"use strict";

const herramientas = ["Firefox", "VS Code", "Vite"];
const lista = document.querySelector("#lista");

for (const nombre of herramientas) {
  const item = document.createElement("li");
  item.textContent = nombre;
  lista.append(item);
}
