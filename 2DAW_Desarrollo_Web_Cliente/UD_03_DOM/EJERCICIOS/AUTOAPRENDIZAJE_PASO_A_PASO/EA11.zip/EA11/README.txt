EA11 - Crear elementos y añadirlos al documento

Abrir estos ficheros dentro de ~/DWEC/UT03/EA11 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
