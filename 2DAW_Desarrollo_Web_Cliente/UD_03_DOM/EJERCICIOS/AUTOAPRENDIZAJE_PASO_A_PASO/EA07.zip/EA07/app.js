"use strict";

const mensaje = document.querySelector("#mensaje");
console.log("Elemento:", mensaje.nodeType, mensaje.nodeName);
console.log("childNodes:", mensaje.childNodes.length);
console.log("children:", mensaje.children.length);

mensaje.childNodes.forEach((nodo) => {
  console.log(nodo.nodeType, nodo.nodeName, nodo.nodeValue);
});
