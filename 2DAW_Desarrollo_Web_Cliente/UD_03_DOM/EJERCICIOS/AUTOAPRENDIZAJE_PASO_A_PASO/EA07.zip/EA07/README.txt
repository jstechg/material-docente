EA07 - Tipos de nodo: Element y Text

Abrir estos ficheros dentro de ~/DWEC/UT03/EA07 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
