EA20 - Panel de avisos: crear, mover, archivar y restaurar

Abrir estos ficheros dentro de ~/DWEC/UT03/EA20 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
