"use strict";

const pendientes = document.querySelector("#pendientes");
const finalizados = document.querySelector("#finalizados");

function crearBoton(texto, accion) {
  const boton = document.createElement("button");
  boton.textContent = texto; boton.dataset.accion = accion; return boton;
}
function crearAviso(texto) {
  const aviso = document.createElement("article"); aviso.className = "aviso";
  const contenido = document.createElement("span"); contenido.textContent = texto;
  aviso.append(contenido, crearBoton("Resolver", "resolver"), crearBoton("Borrar", "borrar"));
  return aviso;
}

document.querySelector("#anadir").addEventListener("click", () => {
  const caja = document.querySelector("#texto"); const texto = caja.value.trim();
  if (!texto) { alert("Escribe un aviso antes de añadirlo."); return; }
  pendientes.append(crearAviso(texto)); caja.value = "";
});

document.body.addEventListener("click", (evento) => {
  const boton = evento.target.closest("button[data-accion]"); if (!boton) return;
  const aviso = boton.closest(".aviso");
  if (boton.dataset.accion === "borrar") aviso.remove();
  if (boton.dataset.accion === "resolver") {
    aviso.classList.add("finalizado"); finalizados.append(aviso);
    boton.textContent = "Reabrir"; boton.dataset.accion = "reabrir";
    aviso.querySelector('[data-accion="borrar"]').textContent = "Archivar"; aviso.querySelector('[data-accion="borrar"]').dataset.accion = "archivar";
  } else if (boton.dataset.accion === "reabrir") {
    aviso.classList.remove("finalizado", "archivado"); pendientes.append(aviso);
    boton.textContent = "Resolver"; boton.dataset.accion = "resolver";
    aviso.querySelector('[data-accion="archivar"]').textContent = "Borrar"; aviso.querySelector('[data-accion="archivar"]').dataset.accion = "borrar";
  } else if (boton.dataset.accion === "archivar") aviso.classList.add("archivado");
});

document.querySelector("#mostrar").addEventListener("click", () => document.querySelectorAll(".archivado").forEach((a) => a.classList.remove("archivado")));
