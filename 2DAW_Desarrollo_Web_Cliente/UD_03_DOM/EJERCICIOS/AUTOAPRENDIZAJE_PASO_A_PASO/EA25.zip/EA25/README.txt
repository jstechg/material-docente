EA25 - Renderizado condicional y listas vacías

Crear primero un proyecto Vite React según el documento EA25.docx. Copiar estos ficheros dentro de src.
