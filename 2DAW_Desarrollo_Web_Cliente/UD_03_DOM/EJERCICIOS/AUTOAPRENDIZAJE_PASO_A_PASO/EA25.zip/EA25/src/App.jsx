import ListaAvisos from "./components/ListaAvisos.jsx";
const avisos = [{ id: 1, texto: "Revisar UT03" }];
function App() { return <main><h1>Avisos</h1><ListaAvisos avisos={avisos} /></main>; }
export default App;
