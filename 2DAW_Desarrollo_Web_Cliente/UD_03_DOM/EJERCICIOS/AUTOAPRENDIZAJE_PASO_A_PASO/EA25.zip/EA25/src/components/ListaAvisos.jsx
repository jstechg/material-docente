function ListaAvisos({ avisos }) {
  return (
    <section>
      {avisos.length > 0
        ? avisos.map((aviso) => <p key={aviso.id}>{aviso.texto}</p>)
        : <p>No hay avisos disponibles.</p>}
    </section>
  );
}
export default ListaAvisos;
