EA23 - Datos JSON y componentes anidados

Crear primero un proyecto Vite React según el documento EA23.docx. Copiar estos ficheros dentro de src.
