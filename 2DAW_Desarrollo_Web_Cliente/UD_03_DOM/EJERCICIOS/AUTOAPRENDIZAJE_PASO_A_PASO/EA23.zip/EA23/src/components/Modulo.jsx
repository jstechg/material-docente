function Modulo({ datos }) {
  return <article><h2>{datos.nombre}</h2><p>{datos.horas} h curriculares/semana</p></article>;
}
export default Modulo;
