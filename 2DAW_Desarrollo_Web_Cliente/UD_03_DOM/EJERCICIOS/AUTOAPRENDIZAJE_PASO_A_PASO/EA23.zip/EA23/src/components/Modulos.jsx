import Modulo from "./Modulo.jsx";
function Modulos({ listado }) {
  return <section>{listado.map((m) => <Modulo key={m.id} datos={m} />)}</section>;
}
export default Modulos;
