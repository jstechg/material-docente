import datos from "./datos/modulos.json";
import Modulos from "./components/Modulos.jsx";
function App() { return <main><h1>Módulos</h1><Modulos listado={datos.modulos} /></main>; }
export default App;
