EA28 - Pasar una referencia a un componente descendiente

Crear primero un proyecto Vite React según el documento EA28.docx. Copiar estos ficheros dentro de src.
