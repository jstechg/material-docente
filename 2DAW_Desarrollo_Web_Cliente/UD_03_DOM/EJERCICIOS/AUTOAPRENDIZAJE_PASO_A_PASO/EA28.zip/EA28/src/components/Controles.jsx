function Controles({ salidaRef }) {
  const escribir = () => { if (salidaRef.current) salidaRef.current.textContent = "Comprobación realizada"; };
  return <button onClick={escribir}>Actualizar salida</button>;
}
export default Controles;
