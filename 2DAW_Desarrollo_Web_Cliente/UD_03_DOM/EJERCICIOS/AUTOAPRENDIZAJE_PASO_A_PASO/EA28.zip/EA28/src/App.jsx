import { useRef } from "react";
import Controles from "./components/Controles.jsx";
function App() {
  const salidaRef = useRef(null);
  return <main><h1>Referencia compartida</h1><Controles salidaRef={salidaRef} /><p ref={salidaRef}>Sin comprobar</p></main>;
}
export default App;
