EA21 - React y DOM: primer componente de UT03

Crear primero un proyecto Vite React según el documento EA21.docx. Copiar estos ficheros dentro de src.
