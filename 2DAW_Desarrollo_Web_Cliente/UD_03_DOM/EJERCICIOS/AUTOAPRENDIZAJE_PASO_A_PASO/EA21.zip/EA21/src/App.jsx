function TarjetaEstado({ titulo, estado }) {
  return <article><h2>{titulo}</h2><p>{estado}</p></article>;
}

function App() {
  return <main><h1>Estado del laboratorio</h1><TarjetaEstado titulo="DOM" estado="Preparado" /></main>;
}
export default App;
