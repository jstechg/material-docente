EA29 - React Router: navegación básica y ruta de error

Crear primero un proyecto Vite React según el documento EA29.docx. Copiar estos ficheros dentro de src.
