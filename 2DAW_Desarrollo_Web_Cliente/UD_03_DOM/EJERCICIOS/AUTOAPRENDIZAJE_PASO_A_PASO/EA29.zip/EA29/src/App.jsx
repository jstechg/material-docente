import { Link, Route, Routes } from "react-router";
const Inicio = () => <h2>Inicio</h2>;
const Agenda = () => <h2>Agenda de prácticas</h2>;
const Acerca = () => <h2>Aplicación de ejemplo UT03</h2>;
const Error = () => <h2>Ruta no encontrada</h2>;
function App() {
  return <main><h1>Aula SPA</h1><nav><Link to="/">Inicio</Link> · <Link to="/agenda">Agenda</Link> · <Link to="/acerca">Acerca de</Link></nav>
    <Routes><Route path="/" element={<Inicio />} /><Route path="/agenda" element={<Agenda />} /><Route path="/acerca" element={<Acerca />} /><Route path="*" element={<Error />} /></Routes></main>;
}
export default App;
