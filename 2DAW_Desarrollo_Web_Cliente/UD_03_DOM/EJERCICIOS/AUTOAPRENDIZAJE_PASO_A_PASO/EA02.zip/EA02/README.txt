EA02 - Árbol DOM: padres, hijos y hermanos

Abrir estos ficheros dentro de ~/DWEC/UT03/EA02 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
