"use strict";

const agenda = document.querySelector("#agenda");
console.log("Padre:", agenda.parentElement.id);
console.log("Hijos elemento:", agenda.children.length);
console.log("Primer hijo:", agenda.firstElementChild.tagName);
console.log("Siguiente hermano del h2:", agenda.firstElementChild.nextElementSibling.textContent);
