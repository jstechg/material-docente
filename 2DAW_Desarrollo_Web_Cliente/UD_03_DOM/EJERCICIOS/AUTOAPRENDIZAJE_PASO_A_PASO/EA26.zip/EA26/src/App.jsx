import { useRef } from "react";

function App() {
  const entradaRef = useRef(null);
  const enfocar = () => entradaRef.current?.focus();
  const mostrar = () => console.log("Valor:", entradaRef.current?.value);
  return (
    <main><h1>Referencia al input</h1><input ref={entradaRef} placeholder="Escribe algo" />
      <button onClick={enfocar}>Enfocar</button><button onClick={mostrar}>Mostrar en consola</button></main>
  );
}
export default App;
