EA26 - useRef para enfocar y leer un elemento DOM

Crear primero un proyecto Vite React según el documento EA26.docx. Copiar estos ficheros dentro de src.
