EA22 - Renderizar listas con map() y keys estables

Crear primero un proyecto Vite React según el documento EA22.docx. Copiar estos ficheros dentro de src.
