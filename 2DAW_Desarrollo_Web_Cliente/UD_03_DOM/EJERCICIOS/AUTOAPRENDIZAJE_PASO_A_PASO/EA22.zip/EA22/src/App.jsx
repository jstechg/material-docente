const recursos = [
  { id: "dom", nombre: "DOM", nivel: "básico" },
  { id: "refs", nombre: "Referencias", nivel: "medio" },
  { id: "rutas", nombre: "Rutas", nivel: "avanzado" }
];

function App() {
  return (
    <main><h1>Recursos</h1><ul>
      {recursos.map((recurso) => <li key={recurso.id}>{recurso.nombre} · {recurso.nivel}</li>)}
    </ul></main>
  );
}
export default App;
