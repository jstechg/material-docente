import { Link, Outlet, Route, Routes, useParams } from "react-router";
import { useRef } from "react";

const recursos = { dom: "Manipulación del DOM", react: "React y referencias" };
const Inicio = () => <h2>Inicio</h2>;
function Recursos() { return <section><h2>Recursos</h2><nav><Link to="dom">DOM</Link> · <Link to="react">React</Link></nav><Outlet /></section>; }
function Lista({ tipo }) { return <p><Link to={`/detalle/${tipo}`}>Abrir detalle de {recursos[tipo]}</Link></p>; }
function Detalle() {
  const { id } = useParams(); const notasRef = useRef(null);
  return <section><h2>Detalle</h2><p>{recursos[id] ?? "Recurso desconocido"}</p><input ref={notasRef} placeholder="Notas" /><button onClick={() => notasRef.current?.focus()}>Enfocar notas</button></section>;
}
const Error = () => <h2>Ruta no encontrada</h2>;
function App() { return <main><h1>Portal UT03</h1><nav><Link to="/">Inicio</Link> · <Link to="/recursos">Recursos</Link></nav><Routes>
  <Route path="/" element={<Inicio />} />
  <Route path="/recursos" element={<Recursos />}><Route path="dom" element={<Lista tipo="dom" />} /><Route path="react" element={<Lista tipo="react" />} /></Route>
  <Route path="/detalle/:id" element={<Detalle />} /><Route path="*" element={<Error />} />
</Routes></main>; }
export default App;
