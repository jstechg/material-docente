EA30 - Miniportal React: rutas anidadas, parámetros y useRef

Crear primero un proyecto Vite React según el documento EA30.docx. Copiar estos ficheros dentro de src.
