"use strict";

const panel = document.querySelector("#panel");
const original = document.querySelector(".tarjeta");
const copia = original.cloneNode(true);
copia.querySelector("h2").textContent = "Copia";
panel.append(copia);

const nuevoTitulo = document.createElement("h2");
nuevoTitulo.textContent = "Original actualizado";
original.querySelector("h2").replaceWith(nuevoTitulo);
document.querySelector("#nota").remove();
