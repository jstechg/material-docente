EA13 - Reemplazar, clonar y eliminar nodos

Abrir estos ficheros dentro de ~/DWEC/UT03/EA13 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
