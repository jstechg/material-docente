EA14 - Lista dinámica con botón y números aleatorios

Abrir estos ficheros dentro de ~/DWEC/UT03/EA14 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
