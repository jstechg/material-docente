"use strict";

const lista = document.querySelector("#valores");
const boton = document.querySelector("#nuevo");

boton.addEventListener("click", () => {
  const numero = Math.floor(Math.random() * 90) + 10;
  const item = document.createElement("li");
  item.textContent = `Valor ${numero}`;
  lista.append(item);
});
