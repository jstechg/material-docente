"use strict";

const mensajes = ["Selecciona primero", "Modifica después", "Comprueba en Inspector", "Documenta el resultado"];
const visor = document.querySelector("#visor");
let indice = 0;
let temporizador = null;

function mostrar() {
  visor.textContent = mensajes[indice];
  visor.classList.toggle("activo");
  indice = (indice + 1) % mensajes.length;
}
function iniciar() { temporizador = setInterval(mostrar, 2000); }

mostrar();
iniciar();
document.querySelector("#pausa").addEventListener("click", (evento) => {
  if (temporizador) { clearInterval(temporizador); temporizador = null; evento.target.textContent = "Reanudar"; }
  else { iniciar(); evento.target.textContent = "Pausar"; }
});
