EA18 - Carrusel temporizado modificando el DOM

Abrir estos ficheros dentro de ~/DWEC/UT03/EA18 y ejecutar:
python3 -m http.server 8000

Después abrir http://localhost:8000
